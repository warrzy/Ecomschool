# Package documentation ECOM-SCHOOL — v2026.11

## Contenu
- manuels-par-profil/ : 10 manuels (PDF + sources DOCX modifiables)
- kit-de-formation/ : démarrage rapide, tutoriels métier, FAQ, glossaire,
  exercices corrigés, checklists, guide admin technique, support PPTX
- documents-commerciaux/ : parcours de démo, guide utilisateur, checklist
  de recette, matrice des fonctionnalités, dossier de présentation,
  paramètres paie BF
- captures-ecran/ : captures réelles annotées (preprod, données fictives)

## Rappels
- Environnement de démonstration : https://preprod.ecomschool.fr
- Données 100 % fictives — aucune donnée réelle n'apparaît
- Paie BF : composants réglementaires désactivés en attente du barème
  officiel — les bulletins produits sont indicatifs
- Généré le 2026-11-14 — ne pas redistribuer les
  identifiants de démonstration
